/* Asteroids model */
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "model.h"
#include "utils.h"
#include "asteroids.h"
#include "controller.h"

//NEW CODE
double AX, AY, BX, BY, CX, CY;
double  hypotenuse = 10;
float angle = 0.0;
float angle_stepsize = 0.5;
//NEW CODE

/* If you want to initialise a linked list:
    You'll have to replace node_t with the right type

typedef struct node {
    some data per node
    struct node *next;
} node_t;
const size_t MAXSize = 10;
node_t data[MAXSize];
node_t *initialise()
{
    int c;
    for(c=0 ; c<(MAXSize-1) ; c++){
        data[c].next = &data[c+1];
    }
    data[c].next = NULL;
    return data;
}
*/
void spinShipLeft() {
		angle -= angle_stepsize;
	
		AX = hypotenuse * cos(angle);
		AY = hypotenuse * sin(angle);
		BX = hypotenuse * cos(angle+2.44346);		//(angle+2.44346)
		BY = hypotenuse * sin(angle+2.44346);		//(angle+2.44346)
		CX = hypotenuse * cos(angle+3.83972);		//(angle+3.83972)
		CY = hypotenuse * sin(angle+3.83972);		//(angle+3.83972)
	
		shipA_x = center_x + AX;
		shipA_y = center_y + AY;
		shipB_x = center_x + BX;
		shipB_y = center_y + BY;
		shipC_x = center_x + CX; 
		shipC_y = center_y + CY;
	
		//missileX = shipA_x;
		//missileY = shipA_y;
		
		leftPress = false;
}

void spinShipRight() {
		angle += angle_stepsize;
	
		AX = hypotenuse * cos(angle);
		AY = hypotenuse * sin(angle);
		BX = hypotenuse * cos(angle+2.44346);
		BY = hypotenuse * sin(angle+2.44346);
		CX = hypotenuse * cos(angle+3.83972);
		CY = hypotenuse * sin(angle+3.83972);
	
		shipA_x = center_x + AX;
		shipA_y = center_y + AY;
		shipB_x = center_x + BX;
		shipB_y = center_y + BY;
		shipC_x = center_x + CX; 
		shipC_y = center_y + CY;
		
		//missileX = shipA_x;	//fires missile
		//missileY = shipA_y;
	
		rightPress = false;
}

void accelerateShip() {
		float vX = 0.1*(hypotenuse * cos (angle));
		float vY = 0.1*(hypotenuse * sin (angle));
	
		center_x += vX;
		center_y += vY;
		shipA_x += vX;
		shipA_y += vY;
		shipB_x += vX;
		shipB_y += vY;
		shipC_x += vX;
		shipC_y += vY;
}

void decelerateShip() {
		float vX = 0.05*(hypotenuse * cos (angle));
		float vY = 0.05*(hypotenuse * sin (angle));

		center_x -= vX;
    center_y -= vY;
		shipA_x -= vX;
		shipA_y -= vY;
		shipB_x -= vX;
		shipB_y -= vY;
		shipC_x -= vX;
		shipC_y -= vY;
}

void newRock(asteroid_t* head) {
		if (asteroidNum < 5) {
			asteroid_t* current = head;
			while (current->next != NULL) {
				current = current->next;
			}
			current->next = (asteroid_t*)malloc(sizeof(asteroid_t));
			current->next->p.x = randrange(16, 465);		//anywhere X coordinate
			current->next->p.y = randrange(16, 257);
			current->next->v.x = randrange(-1, 2);			//go in any Y direction
			current->next->v.y = randrange(-1, 2);
			if (current->next->v.x == 0 && current->next->v.y == 0) {		//if asteroid has no velocity
				current->next->v.x = 1;
				current->next->v.y = 1;
			}
			current->next->next = NULL;
			asteroidNum++;
		}
}

void moveAsteroid(asteroid_t* head) {
	asteroid_t* current = head;
		if (current !=NULL) {
				current->p.x += current->v.x;
				current->p.y += current->v.y;
			
				if (current->p.x>485) {
					current->p.x = -5;
				} if (current->p.x<-5) {
					current->p.x = 485;
				} if (current->p.y>277) {
					current->p.y = -5;
				} if (current->p.y<-5) {
					current->p.y = 277;
				}
				
				current = current->next;
				moveAsteroid(current);
		}
}

void fireMissile(missile_t* head) {
	missile_t* current = head;
		while (current !=NULL) {
				current->p.x += current->v.x;
				current->p.y += current->v.y;
				
				current = current->next;
		}
}

void newMissile(missile_t* head) {
		missile_t* current = head;
	
		while (current->next != NULL) {
			current = current->next;
		}
		current->next = (missile_t*)malloc(sizeof(missile_t));
		
		current->next->p.x = shipA_x;
		current->next->p.y = shipA_y;
		current->next->v.x = 0.5*(hypotenuse * cos (angle));
		current->next->v.y = 0.5*(hypotenuse * sin (angle));
	
		current->next->next = NULL;
}

void physics(void)
{
		newRock(asteroids);
		moveAsteroid(asteroids);
	
		if (leftPress == true) {
				spinShipLeft();
		}
		if (rightPress == true) {
				spinShipRight();
		}
		if (upPress == true) {
				accelerateShip();
		}
		if (downPress == true) {
				decelerateShip();
		}
		
		fireMissile(shots);
}
