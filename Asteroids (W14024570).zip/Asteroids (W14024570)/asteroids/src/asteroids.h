/* Game state */

extern float elapsed_time; /* time this ship has been active */
extern int   score;        /* total score so far */
extern int   lives;        /* lives remaining */
extern int	 shields;

extern int asteroidNum;

extern double center_x;
extern double center_y;

extern double vertexA_x;
extern double vertexA_y;

extern double vertexB_x;
extern double vertexB_y;

extern double vertexC_x;
extern double vertexC_y;

extern double shipA_x;
extern double shipA_y;

extern double shipB_x;
extern double shipB_y;

extern double shipC_x;
extern double shipC_y;



extern struct ship player;

extern struct asteroid_t *asteroids; /* array of rocks / pointer to linked-list */
extern struct missile_t *shots;  /* array of missiles / pointer to linked-list */

extern const float Dt; /* Time step for physics, needed for consistent motion */
