void controls(void);

//extern bool newGame(void);

extern bool leftPress;
extern bool rightPress;
extern bool upPress;
extern bool downPress;
extern bool middlePress;
