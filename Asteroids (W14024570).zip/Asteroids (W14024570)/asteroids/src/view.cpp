/* Asteroids view
*/

/* C libraries */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

/* hardware platform libraries */
#include <display.h>
#include <mbed.h>

#include "asteroids.h"
#include "model.h"
#include "utils.h"

#include "objects.h"

Display *graphics = Display::theDisplay();

const colour_t background = rgb(0,51,102); /* Midnight Blue */

/* double buffering functions */
void init_DBuffer(void)
{   /* initialise the LCD driver to use second frame in buffer */
    uint16_t *bufferbase = graphics->getFb();
    uint16_t *nextbuffer = bufferbase+ (480*272);
    LPC_LCD->UPBASE = (uint32_t)nextbuffer;
}

void swap_DBuffer(void)
{   /* swaps frames used by the LCD driver and the graphics object */
    uint16_t *buffer = graphics->getFb();
    graphics->setFb( (uint16_t*) LPC_LCD->UPBASE);
    LPC_LCD->UPBASE = (uint32_t)buffer;
}

void DrawGameArea() {
	graphics->drawLine(0,15, 480,15, WHITE);
	
	graphics->setCursor(5, 5);
	graphics->printf("Lives: %d", lives);
	
	graphics->setCursor(215,6);
	graphics->printf("Score: %d",score);
	
	graphics->setCursor(380,6);
	graphics->printf("Time: %.0f", elapsed_time);
}

void DrawShip() {
	
		graphics->drawLine(shipA_x,shipA_y, shipB_x,shipB_y, RED);
		graphics->drawLine(shipA_x,shipA_y, shipC_x,shipC_y, RED);
		graphics->drawLine(shipB_x,shipB_y, center_x,center_y, RED);
		graphics->drawLine(shipC_x,shipC_y, center_x,center_y, RED);
	
		if ((shipA_x > 500) && (shipB_x > 480) && (shipC_x > 480)) {
				shipA_x = 0;
				center_x = shipA_x-10;
				shipB_x = center_x-10;
				shipC_x = center_x-10;
		} else if (shipA_x<-10 && shipB_x<0 && shipC_x<0) {
				shipA_x = 480;
				center_x = shipA_x+10;
				shipB_x = center_x+10;
				shipC_x = center_x+10;
		}
		if ((shipA_y > 272) && (shipB_y > 272) && (shipC_y > 272)) {
				shipA_y = 36;
				center_y = shipA_y - 10;
				shipB_y = center_y - 10;
				shipC_y = center_y - 10;
		}
		else if ((shipA_y < 26) && (shipB_y < 26) && (shipC_y < 26)) {
				shipA_y = 272;
				center_y = shipA_y + 10;
				shipB_y = center_y + 10;
				shipC_y = center_y + 10;
		}
}

void DrawShields (asteroid_t* head) {
		asteroid_t* current = head;
		for(int i=1; i<=shields; i++) {
				graphics->drawCircle(center_x, center_y, 15 + (i*3), YELLOW);
		}
		if (((current->p.x + 15) > (center_x-15)) && ((current->p.x + 15) < (center_x + 15)) && ((current->p.y + 15) > (center_y - 15)) && ((current->p.y + 15) < (center_y + 15))) {
			current->p.x = randrange(-10, 490);
			current->p.y = randrange(-10, 282);
			shields--;
			if (shields < 1) {
				score += elapsed_time;
				elapsed_time = 0;
				lives--;
			}
		}
}

void DrawAsteroid (asteroid_t *head) {
		asteroid_t* current = head;
		while (current != NULL) {
			graphics->drawBitmap(current->p.x, current->p.y, asteroid, 16,16, WHITE);
			current = current->next;
		}
}

void DrawMissile(missile_t *head) {
			missile_t* current = head;
			while (current != NULL) {
				graphics->fillCircle(current->p.x, current->p.y, 3, RED);
				current = current->next;
			}
}

void gameOver() {
		swap_DBuffer();
		graphics->fillScreen(background);
		graphics->setTextSize(5);
		graphics->setCursor(100,50);
		graphics->printf("GAME OVER");
		graphics->setCursor(100,150);
		graphics->printf("SCORE: %d",score);
		init_DBuffer();
	}

void increaseTime() {
	elapsed_time += 0.025;
	if (lives < 1) {
		elapsed_time = 0;
	}
}

void draw(void)
{
		graphics->fillScreen(background);
		
		DrawGameArea();
		DrawShip();
		DrawShields(asteroids);
		DrawMissile(shots);
		DrawAsteroid(asteroids);
		increaseTime();
		
		while (lives < 1) {
			gameOver();
		}
	
    swap_DBuffer();
}
