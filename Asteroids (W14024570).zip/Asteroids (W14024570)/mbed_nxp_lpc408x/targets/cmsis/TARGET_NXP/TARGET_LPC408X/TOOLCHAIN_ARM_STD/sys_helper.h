#ifndef SYS_HELPER_H
#define SYS_HELPER_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t __reserved_stack_size();

#ifdef __cplusplus
}
#endif

#endif
